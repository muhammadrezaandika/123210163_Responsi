/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class LombaView {
    
    JLabel lalur = new JLabel("Alur");
    JLabel lorisinalitas = new JLabel("Orisinalitas");
    JLabel lpemilihanKata = new JLabel("Pemilihan kata");
    

    public JTextField tfalur = new JTextField();
    public JTextField tfnorisinalitas = new JTextField();
    public JTextField tfpemilihanKata = new JTextField();
  

    public JButton btnTambah = new JButton("Tambah");
    public JButton btnUpdate = new JButton("Update");
    public JButton btnDelete = new JButton("Delete");
    public JButton btnReset = new JButton("Clear");
    
    public JTable tabel;
    DefaultTableModel dtm;
    JScrollPane scrollPane;
    public Object namaKolom[] = {"Alur", "Orisinalitas", "Pemilihan Kata"};

    public LombaView() {
        dtm = new DefaultTableModel(namaKolom, 0);
        tabel = new JTable(dtm);
        scrollPane = new JScrollPane(tabel);

        setTitle("");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        setResizable(false);
        setLayout(null);
        setSize(700,600);

        add(scrollPane);
        scrollPane.setBounds(20, 20, 480, 300);

        add( lalur);
        lalur.setBounds(510, 20, 90, 20);
        add(tfalur );
        tfalur.setBounds(510, 40, 120, 20);

        add(lorisinalitas);
        lorisinalitas.setBounds(510, 60, 90, 20);
        add(tforisinalitas);
        tforisinalitas.setBounds(510, 80, 120, 20);

        add(lpemilihanKata);
        lpemilihanKata.setBounds(510, 100, 90, 20);
        add(tfpemilihanKata);
        tfpemilihanKata.setBounds(510, 120, 120, 20);

        add(btnTambah);
        btnTambah.setBounds(110, 510, 90, 20);

        add(btnUpdate);
        btnUpdate.setBounds(210, 510, 90, 20);

        add(btnDelete);
        btnDelete.setBounds(310, 510, 90, 20);

        add(btnReset);
        btnReset.setBounds(410, 510, 90, 20);
        btnReset.addActionListener(this);
    
    public void actionPerformed(ActionEvent e) {
     if(e.getSource() == btnReset){
            tfalur.setText("");
            tforisinalitas.setText("");
            tfpemilihanKata.setText("");
        }
     }



    public double getalur(){
        return Double.valueOf( tfalur.getText());
    }

    public String getorisinalitas(){
        return tforisinalitas.getText();
    }

    public double getpemilihanKata(){
        return Double.valueOf(tfpemilihanKata.getText());   
    }
    
}
