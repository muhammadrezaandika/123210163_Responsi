/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import database.Connector;
import main.lomba;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class LombaModel {
    
    Connector con = new Connector();
     public void insertlomba(lomba Lomba){
        String query = "insert into item(alur,orisinalitas,pemilihanKata) values (?,?,?)";
        PreparedStatement pstm;
        
        try{
           con.statement = con.koneksi.createStatement();
           pstm = con.koneksi.prepareStatement(query);
           pstm.setDouble (1, Lomba.getalur());
           pstm.setDouble(2, Lomba.getorisinalitas());
           pstm.setDouble(3, Lomba.getpemilihanKata());
           pstm.executeUpdate();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }   
    }
    
    public ArrayList<lomba> getitem(){
        System.out.println("getitem()");
        String query = "select * from item";
        PreparedStatement pstm;
        
        try{
           con.statement = con.koneksi.createStatement();
           pstm = con.koneksi.prepareStatement(query);
           ResultSet rs = pstm.executeQuery();
           ArrayList<lomba> list = new ArrayList<>();
           lomba Lomba;
           while(rs.next()){
               Lomba = new lomba(
                    rs.getDouble("alur"),
                    rs.getDouble("orisinalitas"),
                    rs.getDouble("pemilihankata")
               );
//               System.out.println(movie.getAlurCerita());
               list.add(Lomba);
           }
           return list;
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return null;
    }
    
    public void updatelomba(lomba Lomba ){
        Connector con = new Connector();
        System.out.println("updatelomba()");
        Lomba.toString(); 
        String query = "update item set alur=?, orisinalitas = ?, pemilihanKata = ? where alur=alur";
        PreparedStatement pstm;
        
        try{
           con.statement = con.koneksi.createStatement();
           pstm = con.koneksi.prepareStatement(query);
           pstm.setDouble(1, Lomba.getalur());
           pstm.setDouble(2, Lomba.getorisinalitas());
           pstm.setDouble(3, Lomba.getpemilihanKata());
           pstm.executeUpdate();
           System.out.println("Update");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void deletelomba(double alur){
        String query = "delete from item where alur = ?";
        PreparedStatement pstm;
        try {
            pstm = con.koneksi.prepareStatement(query);
            pstm.setDouble(1, alur);
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public boolean isContainlomba(){
        System.out.println("isContainlomba()");
        try{
            String query = "select count(*) as num from item";
            PreparedStatement ptsm = con.koneksi.prepareStatement(query);
            con.statement = con.koneksi.createStatement();
            ResultSet rs = ptsm.executeQuery(query);
            rs.next();
            if(rs.getInt("num") > 0) return true;
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return false;
    }
    
}
