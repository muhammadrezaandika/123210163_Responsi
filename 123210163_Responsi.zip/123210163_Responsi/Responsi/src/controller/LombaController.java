/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import model.LombaModel;
import view.LombaView;
import main.lomba;


public class LombaController {
    
    private String judul;
    private double alur;
    private double orisinalitas;
    private double pemilihanKata;
    private double nilai;
    
   
