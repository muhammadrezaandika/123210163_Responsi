/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import database.Connector;

public class lomba {
    
    private String judul;
    private double alur;
    private double orisinalitas;
    private double pemilihanKata;
    private double nilai;
    

    
     public lomba(double alur, double orisinalitas, double pemilihanKata) {
       Connector con = new Connector();  
      
         this.alur = alur;
         this.orisinalitas = orisinalitas;
         this.pemilihanKata = pemilihanKata;
       
    }
     public lomba(String judul, double alur, double orisinalitas, double pemilihanKata, double nilai) {
         this.judul = judul;
         this.alur = alur;
         this.orisinalitas = orisinalitas;
         this.pemilihanKata = pemilihanKata;
         this.nilai = nilai;
       
    }

    public lomba() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public lomba(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    public String getjudul(){
    return judul;
    }
    
    public void setjudul(String judul){
    this.judul = judul;
    }
    
    public double getalur(){
    return alur;
    }
    
    public void setalur(double alur){
    this.alur = alur;
    }
    
    public double getorisinalitas(){
    return orisinalitas;
    }
    
    public void setorisinalitas(double orisinalitas){
    this.orisinalitas = orisinalitas;
    }
    
    public double getpemilihanKata(){
        return pemilihanKata;
    } 
    
    public void setpemilihanKata(double pemilihanKata){
        this.pemilihanKata = pemilihanKata;
    }
    
    public double getnilai(){
        return nilai;
    }
    
    public void setnilai(double nilai){
        this.nilai = nilai;
    }
    
    @Override
    public String toString(){
     return "belanja{" + "juidul=" + judul + ", alur=" + alur + ", orisinalitas=" + orisinalitas + ", pemilihanKata=" + pemilihanKata + ", nilai=" + nilai + '}';   
    }
    
}
