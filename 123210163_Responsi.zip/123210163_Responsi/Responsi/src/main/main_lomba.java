/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import controller.LombaController;
import database.Connector;
import model.LombaModel;
import view.LombaView;

public class main_lomba {
    
     public static void main(String[] args) {
       LombaView view = new LombaView();
       LombaModel model = new LombaModel();
       LombaController controller = new LombaController(view, model);
        
    }
}
